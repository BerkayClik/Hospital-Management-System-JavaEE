create view patient as
select `cs202`.`users`.`u_id`      AS `u_id`,
       `cs202`.`users`.`name`      AS `name`,
       `cs202`.`users`.`pw`        AS `pw`,
       `cs202`.`users`.`user_name` AS `user_name`
from `cs202`.`users`;

