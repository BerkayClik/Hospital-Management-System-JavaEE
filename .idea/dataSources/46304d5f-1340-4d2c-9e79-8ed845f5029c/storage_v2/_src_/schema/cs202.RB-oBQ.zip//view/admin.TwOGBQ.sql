create view admin as
select `cs202`.`users`.`u_id`      AS `u_id`,
       `cs202`.`users`.`name`      AS `name`,
       `cs202`.`users`.`pw`        AS `pw`,
       `cs202`.`users`.`user_name` AS `user_name`,
       `cs202`.`users`.`role_id`   AS `role_id`
from `cs202`.`users`;

